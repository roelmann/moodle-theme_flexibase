    <?php require_once($CFG->dirroot .'/theme/cleanplugged/plugins/awesomebar/topsettings_renderer.php'); ?>
