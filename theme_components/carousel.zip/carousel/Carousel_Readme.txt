Note: In all other themes, consider the folder structure you have used and note that these files are included in a folder structure as used in FlexiBase. You can either replicate this folder structure by simply merging these files into your theme file OR you can copy and paste the code in the files into your own. If you are using any other file/folder structure, then bear in mind that you may need to adjust any given include statements.
These instructions assume that you have followed the existing folder structure and copied the files contained in this zip file.
Don't forget then to change all instances of the theme name (flexibase) to your own theme name. It is useful to make use of a find&replace tool either in your IDE or on the Linux command line etc. Eg
grep -rl "wrong" /home/jerrywaller  | xargs sed -i 's|wrong|right|g'

NOTE: This feature relies on bootstrap js and styles being in place in your theme - it was created using Bootstrap3, but as Bootstrap2 also contains a carousel it should work on BS2 themes But this has NOT yet been tested!

Layout:
Add the following lines to your layout file (usually frontpage.php, within the page-header as shown) where you want the carousel to appear

    <div id="page-header" class="clearfix">
        <!-- Start Carousel -->
        <?php
        $toggleslideshow = theme_flexibase_get_setting('toggleslideshow');
        if ($toggleslideshow == 1) {
            include('includes/carousel2.php');
        } else if ($toggleslideshow == 2 && !isloggedin()) {
            include('includes/carousel2.php');
        } else if ($toggleslideshow == 3 && isloggedin()) {
            include('includes/carousel2.php');
        }
        ?>
        <!-- End Carousel -->

Settings:
Add the include to your settings.php
    include('settings/carousel.php');

Language:
Copy and paste the attached language strings into your own theme language file

Style:
Add the carousel.css file to your theme config.php theme styles list
