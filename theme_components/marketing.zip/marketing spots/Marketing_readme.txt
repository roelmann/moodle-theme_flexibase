Note: In all other themes, consider the folder structure you have used and note that these files are included in a folder structure as used in FlexiBase. You can either replicate this folder structure by simply merging these files into your theme file OR you can copy and paste the code in the files into your own. If you are using any other file/folder structure, then bear in mind that you may need to adjust any given include statements.
These instructions assume that you have followed the existing folder structure and copied the files contained in this zip file.
Don't forget then to change all instances of the theme name (flexibase) to your own theme name. It is useful to make use of a find&replace tool either in your IDE or on the Linux command line etc. Eg
grep -rl "wrong" /home/jerrywaller  | xargs sed -i 's|wrong|right|g'

Note: This version of marketing spots uses flexbox layout rules - this may make it unsuitable for some browsers. However, it can easily be adapted back to bootstrapgrid as used in many other themes. This has not been done here at this stage as this is an intial proof of concept of the theme components idea.

Layout:
Add the following lines to your layout file (usually frontpage.php) where you want the marketing spots to appear

    <div id="page-header" class="clearfix">
        <!-- Start Marketing Spots -->
        <?php
            if($hasmarketing==1) {
                require_once(dirname(__FILE__).'/includes/marketing.php');
            } else if($hasmarketing==2 && !isloggedin()) {
                require_once(dirname(__FILE__).'/includes/marketing.php');
            } else if($hasmarketing==3 && isloggedin()) {
                require_once(dirname(__FILE__).'/includes/marketing.php');
            }
        ?>
        <!-- End Marketing Spots -->

Settings:
Add the include to your settings.php
    include('settings/marketing.php');

Language:
Copy and paste the attached language strings into your own theme language file

Style:
Add the marketing.css file to your theme config.php theme styles list
